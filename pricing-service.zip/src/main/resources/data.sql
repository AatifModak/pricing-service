
INSERT INTO article_details (article_id, store_id, uom, description, brand, model) VALUES
('1000102674', '7001', 'EA', 'WH Halifax Passage Lever in Satin Nickel', 'Weiser', '9GLA1010');

INSERT INTO price (store_id, article_id, type, subtype, currency, amount, valid_from, valid_to, overlapped) VALUES
('7001', '1000102674', 'retail', 'regular', 'CAD', 30.0, '2023-12-31T23:59:59', '9999-12-31T23:59:59', false),
('7001', '1000102674', 'retail', 'discounted', 'CAD', 27.0, '2023-12-21T23:59:59', '2025-12-31T23:59:58', false),
('7001', '1000102674', 'retail', 'discounted', 'CAD', 26.5, '2023-12-21T23:59:59', '2025-12-25T23:59:58', false);
